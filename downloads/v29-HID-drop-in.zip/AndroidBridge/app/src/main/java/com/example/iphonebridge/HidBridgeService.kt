package com.example.iphonebridge

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class HidBridgeService : Service() {
    @Volatile private var adapter: BluetoothAdapter? = null
    @Volatile private var hid: BluetoothHidDevice? = null
    @Volatile private var hidRegistered = false
    @Volatile private var hidProfileRequested = false
    @Volatile private var pendingRegisterHid = false
    @Volatile private var iPhone: BluetoothDevice? = null
    @Volatile private var socket: Socket? = null
    @Volatile private var targetPcIp: String? = null
    private val reconnecting = AtomicBoolean(false)

    private val hidExecutor = Executors.newSingleThreadExecutor()
    private val netExecutor = Executors.newSingleThreadExecutor()
    private val monitorExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val keyboard = ByteArray(8)
    private val mouse = ByteArray(4)
    private var receivedPackets = 0L
    private var lastRejectLogMs = 0L
    private val reportLock = Any()
    private val keyboardLeds = ByteArray(1)
    @Volatile private var registering = false
    @Volatile private var destroyed = false
    @Volatile private var inputInitializedFor: String? = null

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)) {
                BluetoothAdapter.STATE_ON -> registerHid()
                BluetoothAdapter.STATE_OFF -> {
                    hidRegistered = false
                    registering = false
                    hidProfileRequested = false
                    pendingRegisterHid = true
                    iPhone = null
                    inputInitializedFor = null
                    postStatus("Bluetooth выключен — включи его для подключения iPhone")
                }
            }
        }
    }

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE || proxy !is BluetoothHidDevice) return
            if (destroyed) {
                if (hasBluetoothPermission()) adapter?.closeProfileProxy(profile, proxy)
                return
            }
            hid = proxy
            hidProfileRequested = true
            postStatus("HID Device profile готов")
            refreshConnectedIPhone(true)
            if (pendingRegisterHid) {
                pendingRegisterHid = false
                registerHidNow()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = null
                hidProfileRequested = false
                hidRegistered = false
                registering = false
                pendingRegisterHid = true
                inputInitializedFor = null
                iPhone = null
                postStatus("HID profile отключён")
            }
        }
    }

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            registering = false
            hidRegistered = registered
            if (registered) {
                pendingRegisterHid = false
                postStatus("HID зарегистрирован. Подключи iPhone в настройках Bluetooth.")
                // The host may already be connected before this callback arrives.
                refreshConnectedIPhone(true)
            } else {
                inputInitializedFor = null
                iPhone = null
                postStatus("HID регистрация остановлена. Открой приложение и нажми «Подключить HID».")
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    iPhone = device
                    postStatus("iPhone подключён по Bluetooth HID: ${deviceName(device)}")
                    initializePointer(device)
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (iPhone?.address == device.address) {
                        iPhone = null
                        inputInitializedFor = null
                        synchronized(reportLock) { keyboard.fill(0); mouse.fill(0) }
                    }
                    postStatus("iPhone отключён. Подключи его в настройках Bluetooth.")
                }
            }
        }

        override fun onGetReport(device: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            if (!hasBluetoothPermission()) return
            val h = hid ?: return
            val report = synchronized(reportLock) {
                when {
                    type == BluetoothHidDevice.REPORT_TYPE_INPUT && id.toInt() == 1 -> keyboard.copyOf()
                    type == BluetoothHidDevice.REPORT_TYPE_INPUT && id.toInt() == 2 -> mouse.copyOf()
                    type == BluetoothHidDevice.REPORT_TYPE_OUTPUT && id.toInt() == 1 -> keyboardLeds.copyOf()
                    else -> null
                }
            }
            try {
                if (report == null) {
                    h.reportError(device, BluetoothHidDevice.ERROR_RSP_INVALID_RPT_ID)
                } else {
                    h.replyReport(device, type, id, HidReports.controlReply(report, bufferSize))
                }
            } catch (_: SecurityException) { postStatus("Разрешение Bluetooth отозвано") }
        }

        override fun onSetReport(device: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
            if (!hasBluetoothPermission()) return
            val supported = type == BluetoothHidDevice.REPORT_TYPE_OUTPUT && id.toInt() == 1
            val error = when {
                !supported -> BluetoothHidDevice.ERROR_RSP_INVALID_RPT_ID
                data.size != 1 -> BluetoothHidDevice.ERROR_RSP_INVALID_PARAM
                else -> {
                    synchronized(reportLock) { keyboardLeds[0] = data[0] }
                    BluetoothHidDevice.ERROR_RSP_SUCCESS
                }
            }
            try { hid?.reportError(device, error) } catch (_: SecurityException) { }
        }

        override fun onInterruptData(device: BluetoothDevice, reportId: Byte, data: ByteArray) {
            if (reportId.toInt() == 1 && data.size == 1) {
                synchronized(reportLock) { keyboardLeds[0] = data[0] }
            }
        }

        override fun onSetProtocol(device: BluetoothDevice, protocol: Byte) {
            if (!hasBluetoothPermission()) return
            if (protocol == BluetoothHidDevice.PROTOCOL_BOOT_MODE) {
                // This composite descriptor implements report protocol, not boot reports.
                try { hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ) }
                catch (_: SecurityException) { }
            }
        }
        override fun onVirtualCableUnplug(device: BluetoothDevice) {
            if (iPhone?.address == device.address) { iPhone = null; inputInitializedFor = null }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1001, buildNotification("Bluetooth HID service работает в фоне"))
        registerReceiver(bluetoothReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
        initBluetooth()
        postStatus("Фоновый HID-сервис запущен")
        monitorExecutor.scheduleWithFixedDelay({
            if (!destroyed) {
                try { refreshConnectedIPhone(false) }
                catch (e: RuntimeException) { postStatus("Ошибка Bluetooth: ${e.message}") }
            }
        }, 500, 1000, TimeUnit.MILLISECONDS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) registerHid() // Recover after Android restarts the sticky service.
        when (intent?.action) {
            ACTION_REGISTER_HID -> registerHid()
            ACTION_CONNECT_PC -> connectPc(intent.getStringExtra(EXTRA_IP) ?: "")
            ACTION_STOP_PC -> { targetPcIp = null; closeSocket() }
            ACTION_TAP_ABSOLUTE -> {
                val x = intent.getIntExtra(EXTRA_X, 0).coerceIn(0, 828)
                val y = intent.getIntExtra(EXTRA_Y, 0).coerceIn(0, 1792)
                hidExecutor.execute { tapAtIPhone(x, y) }
            }
            ACTION_KEY -> {
                val usage = intent.getIntExtra(EXTRA_KEY, 0)
                hidExecutor.execute { tapKey(usage, 0) }
            }
            ACTION_KEY_CODE -> {
                val usage = intent.getIntExtra(EXTRA_USAGE, 0)
                val modifier = intent.getIntExtra(EXTRA_MODIFIER, 0)
                hidExecutor.execute { tapKey(usage, modifier) }
            }
        }
        return START_STICKY
    }

    private fun hasBluetoothPermission(): Boolean = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun initBluetooth() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            postStatus("Нужно разрешение Bluetooth Connect")
            return
        }
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter
        if (adapter == null) { postStatus("На Android нет Bluetooth"); return }
        if (adapter?.isEnabled != true) { postStatus("Включи Bluetooth на Android"); return }
        postStatus("Bluetooth включён. Загружаю HID Device...")
        try {
            if (hidProfileRequested || hid != null) return
            hidProfileRequested = adapter?.getProfileProxy(this, serviceListener, BluetoothProfile.HID_DEVICE) == true
            if (!hidProfileRequested) postStatus("Этот Android не предоставляет профиль Bluetooth HID Device")
        } catch (e: Exception) {
            hidProfileRequested = false
            postStatus("HID Device недоступен: ${e.message}")
        }
    }

    private fun registerHid() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            postStatus("Нет разрешения Bluetooth Connect")
            return
        }
        if (adapter?.isEnabled != true) {
            pendingRegisterHid = true
            initBluetooth()
            return
        }
        if (hidRegistered) {
            postStatus("HID зарегистрирован. Подключи iPhone в Bluetooth.")
            inputInitializedFor = null
            refreshConnectedIPhone(true)
            return
        }
        val h = hid
        if (h == null) {
            pendingRegisterHid = true
            postStatus("Дождись загрузки HID Device...")
            if (!hidProfileRequested) initBluetooth()
            return
        }
        registerHidNow()
    }

    @Synchronized private fun registerHidNow() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            postStatus("Нет разрешения Bluetooth Connect")
            return
        }
        val h = hid ?: run {
            pendingRegisterHid = true
            postStatus("HID Device ещё загружается...")
            return
        }
        if (hidRegistered || registering) return
        try {
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "iPhone Android Touch",
                "Bluetooth keyboard and mouse",
                "AndroidTouch",
                BluetoothHidDevice.SUBCLASS1_COMBO,
                HidReports.DESCRIPTOR
            )
            registering = true
            if (h.registerApp(sdp, null, null, hidExecutor, hidCallback)) {
                postStatus("Запрос регистрации HID отправлен — ожидаю подтверждение")
            } else {
                registering = false
                postStatus("Android отклонил регистрацию HID. Закрой другие HID-приложения и повтори.")
            }
        } catch (e: SecurityException) {
            registering = false
            postStatus("Нет Bluetooth-разрешения: ${e.message}")
        } catch (e: Exception) {
            registering = false
            postStatus("Ошибка регистрации HID: ${e.message}")
        }
    }

    private fun connectPc(ip: String) {
        if (ip.isEmpty()) { postStatus("Введи IP компьютера"); return }
        targetPcIp = ip
        closeSocket()
        startReconnectLoop()
    }

    private fun startReconnectLoop() {
        if (destroyed || !reconnecting.compareAndSet(false, true)) return
        netExecutor.execute {
            try {
                while (!destroyed) {
                    val ip = targetPcIp ?: break
                    val s = Socket()
                    try {
                        // Publish the socket before connecting so Stop can cancel
                        // both a blocking connect and a blocking read.
                        socket = s
                        if (targetPcIp != ip || destroyed) continue
                        s.tcpNoDelay = true
                        s.keepAlive = true
                        s.connect(InetSocketAddress(ip, 45678), 2500)
                        if (targetPcIp != ip || destroyed) continue
                        postStatus("ПК подключён: $ip:45678")
                        val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                        while (!destroyed && targetPcIp == ip && !s.isClosed) {
                            val line = reader.readLine() ?: break
                            handlePacket(line)
                        }
                    } catch (_: java.io.IOException) {
                        if (targetPcIp != null && !destroyed) postStatus("ПК недоступен, переподключение...")
                    } finally {
                        try { s.close() } catch (_: java.io.IOException) { }
                        if (socket === s) socket = null
                        // Do not leave the iPhone with a held key/button when the
                        // TCP sender disappears before sending its release packet.
                        synchronized(reportLock) { keyboard.fill(0); mouse.fill(0) }
                        send(1, ByteArray(8))
                        send(2, ByteArray(4))
                    }
                    if (targetPcIp != null && !destroyed) Thread.sleep(800)
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                reconnecting.set(false)
                if (targetPcIp != null && !destroyed) startReconnectLoop()
            }
        }
    }

    private fun handlePacket(line: String) {
        val packet = HidReports.parsePacket(line) ?: return
        synchronized(reportLock) {
            packet.data.copyInto(if (packet.id == 1) keyboard else mouse)
            if (packet.id == 2) { mouse[1] = 0; mouse[2] = 0; mouse[3] = 0 }
        }
        receivedPackets++
        send(packet.id, packet.data)
    }

    @Synchronized private fun initializePointer(device: BluetoothDevice) {
        if (!hidRegistered || inputInitializedFor == device.address || destroyed) return
        // Start with released inputs. One small relative movement wakes the iOS
        // pointer without clicking, calibrating or moving it to a screen corner.
        synchronized(reportLock) { keyboard.fill(0); mouse.fill(0) }
        send(1, ByteArray(8))
        if (send(2, byteArrayOf(0, 1, 0, 0))) {
            send(2, byteArrayOf(0, -1, 0, 0))
            send(2, ByteArray(4))
            inputInitializedFor = device.address
            postStatus("Мышь HID готова. На iPhone должен быть включён AssistiveTouch.")
        }
    }

    private fun refreshConnectedIPhone(reportStatus: Boolean) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val h = hid ?: return
        if (!hidRegistered) return
        try {
            val devices = h.connectedDevices
            val found = devices.firstOrNull()
            if (found != null) {
                val changed = iPhone?.address != found.address
                iPhone = found
                if (changed || reportStatus) {
                    postStatus("iPhone подключён по Bluetooth HID: ${deviceName(found)}")
                }
                initializePointer(found)
            } else if (iPhone != null) {
                iPhone = null
                inputInitializedFor = null
                postStatus("iPhone HID больше не подключён")
            }
        } catch (_: SecurityException) { }
    }

    /**
     * Relative HID is used as the compatibility path for iOS. We deliberately
     * "home" the cursor first with large negative movements, then move to the
     * requested iPhone-11 coordinate. This makes an Android tap behave like a
     * screen tap instead of a normal trackpad movement.
     */
    private fun tapAtIPhone(x: Int, y: Int) {
        if (!ensureIPhone()) return
        repeat(18) {
            sendMouseRelative(-127, -127, 0)
            Thread.sleep(3)
        }
        moveAxis(x, true)
        moveAxis(y, false)
        Thread.sleep(12)
        sendMouseRelative(0, 0, 1)
        Thread.sleep(18)
        sendMouseRelative(0, 0, 0)
        postStatus("Tap sent: iPhone $x,$y")
    }

    private fun moveAxis(value: Int, xAxis: Boolean) {
        var remaining = value.coerceIn(0, 1792)
        if (xAxis) remaining = value.coerceIn(0, 828)
        while (remaining > 0) {
            val step = minOf(remaining, 127)
            if (xAxis) sendMouseRelative(step, 0, 0) else sendMouseRelative(0, step, 0)
            remaining -= step
            Thread.sleep(2)
        }
    }

    private fun sendMouseRelative(dx: Int, dy: Int, buttons: Int) {
        val report = byteArrayOf(buttons.coerceIn(0, 7).toByte(),
            dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), 0)
        synchronized(reportLock) {
            mouse.fill(0)
            mouse[0] = report[0]
        }
        send(2, report)
    }

    private fun tapKey(usage: Int, modifier: Int) {
        val report = ByteArray(8)
        report[0] = modifier.coerceIn(0, 255).toByte()
        report[2] = usage.coerceIn(0, 255).toByte()
        synchronized(reportLock) { report.copyInto(keyboard) }
        send(1, report)
        try { Thread.sleep(12) }
        finally {
            synchronized(reportLock) { keyboard.fill(0) }
            send(1, ByteArray(8))
        }
    }

    private fun ensureIPhone(): Boolean {
        refreshConnectedIPhone(false)
        if (iPhone == null) {
            postStatus("iPhone HID не подключён — включи AssistiveTouch и подключи iPhone")
            return false
        }
        return true
    }

    private fun send(reportId: Int, data: ByteArray): Boolean {
        if (!hasBluetoothPermission()) return false
        val h = hid ?: return false
        val phone = iPhone ?: return false
        if (!hidRegistered) return false
        return try {
            val ok = h.sendReport(phone, reportId, data.copyOf())
            if (!ok) {
                val now = System.currentTimeMillis()
                if (now - lastRejectLogMs > 2000) {
                    lastRejectLogMs = now
                    postStatus("Bluetooth не принял HID report $reportId — переподключи iPhone")
                }
            }
            ok
        } catch (_: SecurityException) { false }
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: Exception) { }
        socket = null
    }

    private fun postStatus(message: String) {
        getSharedPreferences("bridge_state", MODE_PRIVATE).edit().putString("last_status", message).apply()
        val intent = Intent(ACTION_STATUS).setPackage(packageName)
        intent.putExtra(EXTRA_MESSAGE, message)
        sendBroadcast(intent)
    }

    private fun deviceName(device: BluetoothDevice): String = try { device.name ?: device.address } catch (_: SecurityException) { device.address }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "iPhone Android Touch", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("iPhone Android Touch")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("iPhone Android Touch")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setOngoing(true)
                .build()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        destroyed = true
        targetPcIp = null
        monitorExecutor.shutdownNow()
        unregisterReceiver(bluetoothReceiver)
        closeSocket()
        if (hasBluetoothPermission()) {
            try { hid?.unregisterApp() } catch (_: SecurityException) { }
            try { hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } }
            catch (_: SecurityException) { }
        }
        hidExecutor.shutdownNow()
        netExecutor.shutdownNow()
        hid = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_REGISTER_HID = "com.example.iphonebridge.REGISTER_HID"
        const val ACTION_CONNECT_PC = "com.example.iphonebridge.CONNECT_PC"
        const val ACTION_STOP_PC = "com.example.iphonebridge.STOP_PC"
        const val ACTION_TAP_ABSOLUTE = "com.example.iphonebridge.TAP_ABSOLUTE"
        const val ACTION_KEY = "com.example.iphonebridge.KEY"
        const val ACTION_KEY_CODE = "com.example.iphonebridge.KEY_CODE"
        const val ACTION_STATUS = "com.example.iphonebridge.STATUS"
        const val EXTRA_IP = "ip"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_X = "x"
        const val EXTRA_Y = "y"
        const val EXTRA_KEY = "key"
        const val EXTRA_USAGE = "usage"
        const val EXTRA_MODIFIER = "modifier"
        private const val CHANNEL_ID = "iphone_bridge_hid"
    }
}
