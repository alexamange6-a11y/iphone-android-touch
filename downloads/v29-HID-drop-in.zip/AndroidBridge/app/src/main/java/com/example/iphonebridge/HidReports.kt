package com.example.iphonebridge

/** Wire format shared by the Bluetooth control channel and PC input. */
object HidReports {
    const val KEYBOARD_ID = 1
    const val MOUSE_ID = 2

    data class Packet(val id: Int, val data: ByteArray)

    fun controlReply(report: ByteArray, bufferSize: Int): ByteArray {
        // Zero means the host did not specify a maximum, not a zero-byte report.
        return if (bufferSize <= 0) report.copyOf() else report.copyOf(minOf(bufferSize, report.size))
    }

    fun parsePacket(line: String): Packet? {
        val fields = line.trim().split(',')
        val values = fields.drop(1).map { it.trim().toIntOrNull() ?: return null }
        return when (fields.firstOrNull()) {
            "K" -> {
                if (values.size !in 7..8 || values.any { it !in 0..255 }) return null
                val data = ByteArray(8)
                data[0] = values[0].toByte()
                val offset = if (values.size == 7) 1 else 2
                for (i in 0 until 6) data[i + 2] = values[i + offset].toByte()
                Packet(KEYBOARD_ID, data)
            }
            "M" -> {
                if (values.size != 4 || values[0] !in 0..7 || values.drop(1).any { it !in -127..127 }) return null
                Packet(MOUSE_ID, values.map { it.toByte() }.toByteArray())
            }
            else -> null
        }
    }

    // Keep report IDs and sizes stable so existing iPhone pairings and PC clients
    // retain the same keyboard (8 bytes), mouse (4 bytes) and LED (1 byte) layout.
    val DESCRIPTOR: ByteArray = intArrayOf(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00,
        0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x05,
        0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05,
        0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65,
        0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
        0xC0, 0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85,
        0x02, 0x09, 0x01, 0xA1, 0x00, 0x05, 0x09, 0x19,
        0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95,
        0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75,
        0x05, 0x81, 0x01, 0x05, 0x01, 0x09, 0x30, 0x09,
        0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75,
        0x08, 0x95, 0x03, 0x81, 0x06, 0xC0, 0xC0
    ).map { it.toByte() }.toByteArray()
}
