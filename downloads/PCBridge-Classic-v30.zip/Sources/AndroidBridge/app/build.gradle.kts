plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.iphonebridge"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.iphonebridge"
        minSdk = 28
        targetSdk = 35
        versionCode = 6
        versionName = "1.5-classic-low-latency"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    testImplementation("junit:junit:4.13.2")
}
