package com.example.iphonebridge

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var pcIp: EditText
    private var pendingAction: (() -> Unit)? = null
    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == HidBridgeService.ACTION_STATUS) {
                status.text = intent.getStringExtra(HidBridgeService.EXTRA_MESSAGE).orEmpty()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        makeUi()
        withBluetoothPermission { startHid() }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, statusReceiver,
            IntentFilter(HidBridgeService.ACTION_STATUS), ContextCompat.RECEIVER_NOT_EXPORTED)
        status.text = getSharedPreferences("bridge_state", MODE_PRIVATE)
            .getString("last_status", "Включи Bluetooth и подключи HID")
    }

    override fun onStop() {
        unregisterReceiver(statusReceiver)
        super.onStop()
    }

    private fun withBluetoothPermission(action: () -> Unit) {
        val required = if (Build.VERSION.SDK_INT >= 31) listOf(
            Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE
        ) else emptyList()
        val missing = required.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toMutableList()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        if (missing.isEmpty()) action() else {
            pendingAction = action
            requestPermissions(missing.toTypedArray(), 100)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode != 100) return
        val action = pendingAction
        pendingAction = null
        // Notification permission is optional; Bluetooth permission is required
        // before creating a connectedDevice foreground service on Android 14+.
        val bluetoothAllowed = Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED)
        if (bluetoothAllowed) action?.invoke()
        else status.text = "Разреши доступ к устройствам поблизости, затем нажми «Подключить HID»."
    }

    private fun startHid() {
        startForegroundService(Intent(this, HidBridgeService::class.java).setAction(HidBridgeService.ACTION_REGISTER_HID))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun makeUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(24))
            setBackgroundColor(Color.rgb(244, 247, 251))
        }
        fun label(text: String, size: Float, color: Int = Color.rgb(27, 42, 65)) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                setPadding(0, dp(8), 0, dp(12))
            })
        }
        fun button(text: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                this.text = text
                isAllCaps = false
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
        label("iPhone Bridge", 28f)
        label("Классическое управление с ПК", 15f)
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(24, 72, 126))
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
            }
            accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        button("Подключить HID / проверить курсор") { withBluetoothPermission { startHid() } }
        button("Сопряжение с iPhone") {
            withBluetoothPermission {
                startHid()
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
            }
        }
        button("Настройки Bluetooth") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        label("Управление с ПК", 19f)
        pcIp = EditText(this).apply {
            hint = "IP компьютера, например 192.168.1.10"
            contentDescription = "IP компьютера"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setText(getSharedPreferences("bridge_state", MODE_PRIVATE).getString("pc_ip", ""))
        }
        root.addView(pcIp)
        button("Подключить ПК") {
            val ip = pcIp.text.toString().trim()
            if (ip.isEmpty()) status.text = "Введи IP компьютера с запущенным PCBridge."
            else withBluetoothPermission {
                getSharedPreferences("bridge_state", MODE_PRIVATE).edit().putString("pc_ip", ip).apply()
                startHid()
                startForegroundService(Intent(this, HidBridgeService::class.java)
                    .setAction(HidBridgeService.ACTION_CONNECT_PC).putExtra(HidBridgeService.EXTRA_IP, ip))
            }
        }
        button("Отключить ПК") {
            withBluetoothPermission {
                startForegroundService(Intent(this, HidBridgeService::class.java).setAction(HidBridgeService.ACTION_STOP_PC))
            }
        }
        label("1. Включи AssistiveTouch на iPhone.\n2. Нажми «Подключить HID», затем выполни сопряжение с iPhone.\n3. Для управления с ПК запусти PCBridge и введи его IP.\n\nAndroid не может включить AssistiveTouch на iPhone удалённо.", 14f)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    companion object {
        val REPORT_DESCRIPTOR: ByteArray get() = HidReports.DESCRIPTOR
    }
}
