package com.example.iphonebridge

/** Wire format shared by the Bluetooth control channel and PC input. */
object HidReports {
    const val KEYBOARD_ID = 1
    const val MOUSE_ID = 2

    data class Packet(val id: Int, val data: ByteArray)

    fun controlReply(report: ByteArray, bufferSize: Int): ByteArray {
        // Zero means the host did not specify a maximum, not a zero-byte report.
        return if (bufferSize <= 0) report.copyOf() else report.copyOf(minOf(bufferSize, report.size))
    }

    fun parsePacket(line: String): Packet? {
        // The mouse runs at input-event rate: scan numbers directly instead of
        // allocating split lists, boxed integers and mapped intermediate lists.
        var start = 0
        var end = line.length
        while (start < end && line[start].isWhitespace()) start++
        while (end > start && line[end - 1].isWhitespace()) end--
        if (end - start < 3 || line[start + 1] != ',') return null
        val kind = line[start]
        if (kind != 'M' && kind != 'K') return null
        val values = IntArray(8)
        var count = 0
        var cursor = start + 2
        while (cursor < end) {
            if (count == values.size) return null
            while (cursor < end && line[cursor].isWhitespace()) cursor++
            var sign = 1
            if (cursor < end && (line[cursor] == '-' || line[cursor] == '+')) {
                if (line[cursor] == '-') sign = -1
                cursor++
            }
            val digitStart = cursor
            var value = 0
            while (cursor < end && line[cursor] in '0'..'9') {
                value = value * 10 + (line[cursor] - '0')
                if (value > 255) return null // Also prevents integer overflow.
                cursor++
            }
            if (cursor == digitStart) return null
            while (cursor < end && line[cursor].isWhitespace()) cursor++
            values[count++] = value * sign
            if (cursor == end) break
            if (line[cursor++] != ',' || cursor == end) return null
        }
        if (kind == 'K') {
            if (count !in 7..8) return null
            for (i in 0 until count) if (values[i] !in 0..255) return null
            val data = ByteArray(8)
            data[0] = values[0].toByte()
            val offset = if (count == 7) 1 else 2
            for (i in 0 until 6) data[i + 2] = values[i + offset].toByte()
            return Packet(KEYBOARD_ID, data)
        }
        if (count != 4 || values[0] !in 0..7) return null
        for (i in 1..3) if (values[i] !in -127..127) return null
        return Packet(MOUSE_ID, byteArrayOf(values[0].toByte(), values[1].toByte(),
            values[2].toByte(), values[3].toByte()))
    }

    // Keep report IDs and sizes stable so existing iPhone pairings and PC clients
    // retain the same keyboard (8 bytes), mouse (4 bytes) and LED (1 byte) layout.
    val DESCRIPTOR: ByteArray = intArrayOf(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00,
        0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x05,
        0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05,
        0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65,
        0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
        0xC0, 0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85,
        0x02, 0x09, 0x01, 0xA1, 0x00, 0x05, 0x09, 0x19,
        0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95,
        0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75,
        0x05, 0x81, 0x01, 0x05, 0x01, 0x09, 0x30, 0x09,
        0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75,
        0x08, 0x95, 0x03, 0x81, 0x06, 0xC0, 0xC0
    ).map { it.toByte() }.toByteArray()
}
