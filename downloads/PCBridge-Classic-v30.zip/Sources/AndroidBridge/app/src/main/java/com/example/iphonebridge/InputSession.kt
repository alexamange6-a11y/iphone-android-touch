package com.example.iphonebridge

/** Serializes input with disconnect/reconnect and rejects buffered stale commands. */
class InputSession {
    private val lock = Any()
    @Volatile var generation = 0L
        private set

    fun replace(action: () -> Unit) = synchronized(lock) {
        generation++
        action()
    }

    fun dispatch(expectedGeneration: Long, action: () -> Unit): Boolean = synchronized(lock) {
        if (generation != expectedGeneration) false
        else { action(); true }
    }

    fun <T> exclusive(action: () -> T): T = synchronized(lock, action)
}
