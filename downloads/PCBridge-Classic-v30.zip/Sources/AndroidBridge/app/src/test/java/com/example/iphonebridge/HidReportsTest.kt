package com.example.iphonebridge

import org.junit.Assert.*
import org.junit.Test

class HidReportsTest {
    @Test fun getReportWithoutHostLimitReturnsFullMouseReport() {
        val report = byteArrayOf(1, 2, 3, 4)
        val reply = HidReports.controlReply(report, 0)
        assertArrayEquals(report, reply)
        reply[0] = 7
        assertEquals(1, report[0].toInt())
    }

    @Test fun getReportRespectsPositiveLimitWithoutPadding() {
        assertArrayEquals(byteArrayOf(1, 2), HidReports.controlReply(byteArrayOf(1, 2, 3, 4), 2))
        assertEquals(8, HidReports.controlReply(ByteArray(8), 64).size)
        assertEquals(1, HidReports.controlReply(byteArrayOf(2), 0).size)
    }

    @Test fun pcKeyboardPacketInsertsReservedByteAndKeepsAllSixKeys() {
        val packet = HidReports.parsePacket("K,8,4,5,6,7,8,9")!!
        assertEquals(1, packet.id)
        assertArrayEquals(byteArrayOf(8, 0, 4, 5, 6, 7, 8, 9), packet.data)
    }

    @Test fun keyboardPacketWithExplicitReservedByteIsAlsoSupported() {
        val packet = HidReports.parsePacket("K,2,0,4,0,0,0,0,0")!!
        assertArrayEquals(byteArrayOf(2, 0, 4, 0, 0, 0, 0, 0), packet.data)
    }

    @Test fun mousePacketPreservesNegativeMotionAndWheel() {
        val packet = HidReports.parsePacket("M,3,-127,127,-1")!!
        assertEquals(2, packet.id)
        assertArrayEquals(byteArrayOf(3, -127, 127, -1), packet.data)
    }

    @Test fun corruptPacketsAreIgnoredWithoutClampingIntoPressedInputs() {
        for (line in listOf("", "K,0,4", "K,256,4,0,0,0,0,0", "M,1,x,0,0", "M,8,0,0,0", "M,0,-128,0,0", "M,0,0,0", "X,1,2,3,4")) {
            assertNull(line, HidReports.parsePacket(line))
        }
    }

    @Test fun fastParserAcceptsWhitespaceSignsAndRejectsOverflowAndTrailingFields() {
        assertArrayEquals(byteArrayOf(1, -127, 127, 0),
            HidReports.parsePacket("  M, 1 , -127 , +127 , 0 \r\n")!!.data)
        for (line in listOf("M,0,0,0,0,", "M,0,0,0,0,1", "M,0,99999999999999999999,0,0",
            "M,0,--1,0,0", "K,0,0,0,0,0,0,0,0,0", "M,0,1 2,0,0")) assertNull(line, HidReports.parsePacket(line))
    }

    @Test fun burstKeepsEveryMotionAndButtonTransitionInOrder() {
        val lines = listOf("M,0,127,-1,0", "M,0,127,-1,0", "M,1,0,0,0", "M,1,7,2,-1", "M,0,0,0,0")
        val packets = lines.map { HidReports.parsePacket(it)!! }
        assertEquals(listOf(0, 0, 1, 1, 0), packets.map { it.data[0].toInt() })
        assertEquals(261, packets.sumOf { it.data[1].toInt() })
        assertEquals(0, packets.sumOf { it.data[2].toInt() })
        assertEquals(-1, packets.sumOf { it.data[3].toInt() })
    }

    @Test fun descriptorMatchesReportIdsAndPayloadLengths() {
        // Parse HID short items rather than matching a duplicate descriptor.
        val bytes = HidReports.DESCRIPTOR.map { it.toInt() and 255 }
        val sizes = mutableMapOf<Pair<Int, Int>, Int>()
        val stack = mutableListOf<Triple<Int, Int, Int>>()
        var size = 0
        var count = 0
        var id = 0
        var offset = 0
        var collections = 0
        while (offset < bytes.size) {
            val prefix = bytes[offset++]
            val length = when (prefix and 3) { 3 -> 4; else -> prefix and 3 }
            var value = 0
            repeat(length) { value = value or (bytes[offset++] shl (it * 8)) }
            when (prefix and 0xFC) {
                0x74 -> size = value
                0x94 -> count = value
                0x84 -> id = value
                0xA4 -> stack.add(Triple(size, count, id))
                0xB4 -> stack.removeAt(stack.lastIndex).let { size = it.first; count = it.second; id = it.third }
                0x80, 0x90 -> {
                    val key = Pair(id, prefix and 0xFC)
                    sizes[key] = (sizes[key] ?: 0) + size * count
                }
                0xA0 -> collections++
                0xC0 -> collections--
            }
        }
        assertEquals(0, collections)
        assertEquals(mapOf(Pair(1, 0x80) to 64, Pair(1, 0x90) to 8, Pair(2, 0x80) to 32), sizes)
    }
}
