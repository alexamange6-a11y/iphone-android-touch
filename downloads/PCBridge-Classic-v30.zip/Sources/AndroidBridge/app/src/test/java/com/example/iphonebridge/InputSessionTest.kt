package com.example.iphonebridge

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class InputSessionTest {
    @Test fun bufferedCommandsFromOldConnectionCannotRunAfterReconnect() {
        val session = InputSession()
        val oldConnection = session.generation
        val events = mutableListOf<String>()
        assertTrue(session.dispatch(oldConnection) { events.add("press") })
        session.replace { events.add("release") }
        assertFalse(session.dispatch(oldConnection) { events.add("stale drag") })
        assertTrue(session.dispatch(session.generation) { events.add("new motion") })
        assertEquals(listOf("press", "release", "new motion"), events)
    }

    @Test fun stopReleasesInputsAfterInflightPacketAndRejectsItsBufferedSuccessor() {
        val session = InputSession()
        val generation = session.generation
        val packetStarted = CountDownLatch(1)
        val finishPacket = CountDownLatch(1)
        val stopAttempted = CountDownLatch(1)
        val events = mutableListOf<String>()
        val workers = Executors.newFixedThreadPool(2)
        try {
            val packet = workers.submit {
                session.dispatch(generation) {
                    events.add("press")
                    packetStarted.countDown()
                    check(finishPacket.await(2, TimeUnit.SECONDS))
                    events.add("packet completed")
                }
            }
            assertTrue(packetStarted.await(2, TimeUnit.SECONDS))
            val stop = workers.submit {
                stopAttempted.countDown()
                session.replace { events.add("release") }
            }
            assertTrue(stopAttempted.await(2, TimeUnit.SECONDS))
            finishPacket.countDown()
            packet.get(2, TimeUnit.SECONDS)
            stop.get(2, TimeUnit.SECONDS)
            assertFalse(session.dispatch(generation) { events.add("stale press") })
            assertEquals(listOf("press", "packet completed", "release"), events)
        } finally {
            finishPacket.countDown()
            workers.shutdownNow()
        }
    }

    @Test fun initializationCanRunInsideForwardingWithoutDeadlock() {
        val session = InputSession()
        val events = mutableListOf<String>()
        session.dispatch(session.generation) {
            session.exclusive { events.add("initialize") }
            events.add("press")
        }
        assertEquals(listOf("initialize", "press"), events)
    }
}
