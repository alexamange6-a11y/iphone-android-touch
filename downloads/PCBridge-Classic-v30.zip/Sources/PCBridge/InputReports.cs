
namespace PCBridge;

// Movement is summed only across adjacent mouse reports with identical buttons.
// Keyboard reports and button transitions remain FIFO barriers.
internal sealed class InputReportQueue
{
    private sealed class Report
    {
        public string? Keyboard;
        public int Buttons;
        public long Dx, Dy, Wheel;
    }

    private readonly object _sync = new();
    private readonly LinkedList<Report> _reports = new();
    private readonly int _capacity;
    public InputReportQueue(int capacity = 256) => _capacity = capacity;

    // newEntry controls the writer's wake-up count; merging adds no extra wakeup.
    public bool TryEnqueue(string line, out bool newEntry)
    {
        newEntry = false;
        var fields = line.Split(',');
        Report report;
        if (fields.Length == 5 && fields[0] == "M" &&
            int.TryParse(fields[1], out var buttons) && buttons is >= 0 and <= 7 &&
            int.TryParse(fields[2], out var dx) && int.TryParse(fields[3], out var dy) && int.TryParse(fields[4], out var wheel))
        {
            report = new Report { Buttons = buttons, Dx = dx, Dy = dy, Wheel = wheel };
        }
        else if (fields.Length == 8 && fields[0] == "K" && fields.Skip(1).All(x => byte.TryParse(x, out _)))
        {
            report = new Report { Keyboard = line };
        }
        else return false;
        lock (_sync)
        {
            if (report.Keyboard is null && _reports.Last?.Value is { Keyboard: null } last && last.Buttons == report.Buttons)
            {
                last.Dx += report.Dx;
                last.Dy += report.Dy;
                last.Wheel += report.Wheel;
                return true;
            }
            if (_reports.Count >= _capacity) return false;
            _reports.AddLast(report);
            newEntry = true;
            return true;
        }
    }

    public IEnumerable<string> DequeueLines()
    {
        Report report;
        lock (_sync)
        {
            if (_reports.First is null) throw new InvalidOperationException("No queued report");
            report = _reports.First.Value;
            _reports.RemoveFirst();
        }
        if (report.Keyboard is not null) { yield return report.Keyboard; yield break; }
        do
        {
            var dx = Math.Clamp(report.Dx, -127, 127);
            var dy = Math.Clamp(report.Dy, -127, 127);
            var wheel = Math.Clamp(report.Wheel, -127, 127);
            yield return FormattableString.Invariant($"M,{report.Buttons},{dx},{dy},{wheel}");
            report.Dx -= dx;
            report.Dy -= dy;
            report.Wheel -= wheel;
        } while (report.Dx != 0 || report.Dy != 0 || report.Wheel != 0);
    }
}

internal sealed class MouseMotionScaler
{
    private double _fractionX, _fractionY;
    private int _wheelRemainder;
    public (int Dx, int Dy) Scale(int dx, int dy, double speed)
    {
        _fractionX += dx * speed;
        _fractionY += dy * speed;
        var x = (int)Math.Truncate(_fractionX);
        var y = (int)Math.Truncate(_fractionY);
        _fractionX -= x;
        _fractionY -= y;
        return (x, y);
    }
    public int ScaleWheel(short rawDelta)
    {
        _wheelRemainder += rawDelta;
        var steps = _wheelRemainder / 120;
        _wheelRemainder %= 120;
        return steps;
    }
    public void Reset() { _fractionX = _fractionY = 0; _wheelRemainder = 0; }
}
