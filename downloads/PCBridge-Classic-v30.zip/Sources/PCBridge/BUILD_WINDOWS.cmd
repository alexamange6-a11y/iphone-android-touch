@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo Install .NET 8 SDK from https://dotnet.microsoft.com/download/dotnet/8.0
  exit /b 1
)
dotnet publish PCBridge.csproj --configuration Release --runtime win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true --output publish\win-x64
if errorlevel 1 exit /b 1
echo Ready: %CD%\publish\win-x64\PCBridge.exe
endlocal
