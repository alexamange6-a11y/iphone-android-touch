using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace PCBridge;

internal sealed class NetworkBridge
{
    private sealed class Session
    {
        public readonly TcpClient Client;
        public readonly InputReportQueue Queue = new();
        public readonly SemaphoreSlim Pending = new(0);
        public readonly CancellationTokenSource Stop = new();
        public Task Writer = Task.CompletedTask;
        public Task Reader = Task.CompletedTask;
        public Session(TcpClient client) => Client = client;
        public void Close()
        {
            Stop.Cancel();
            Client.Dispose();
        }
    }

    private readonly int _port;
    private readonly object _sync = new();
    private TcpListener? _listener;
    private CancellationTokenSource? _stop;
    private Task _acceptTask = Task.CompletedTask;
    private Session? _session;
    public bool IsConnected { get { lock (_sync) return _session is not null; } }
    public int LocalPort => (_listener?.LocalEndpoint as IPEndPoint)?.Port ?? _port;
    public event Action<bool>? ClientChanged;
    public event Action<string>? Log;
    public NetworkBridge(int port) => _port = port;

    public Task StartAsync()
    {
        if (_listener is not null) return Task.CompletedTask;
        var listener = new TcpListener(IPAddress.Any, _port);
        listener.Start();
        _listener = listener;
        _stop = new CancellationTokenSource();
        _acceptTask = AcceptLoopAsync(listener, _stop.Token);
        return Task.CompletedTask;
    }

    public void Send(string line)
    {
        Session? session;
        lock (_sync) session = _session;
        if (session is null) return;
        if (!session.Queue.TryEnqueue(line, out var added))
        {
            Disconnect(session, "Input queue overloaded; disconnected to avoid stuck input. Reconnect Android.");
            return;
        }
        if (added) session.Pending.Release();
    }

    private async Task WriteLoopAsync(Session session)
    {
        try
        {
            var stream = session.Client.GetStream();
            while (!session.Stop.IsCancellationRequested)
            {
                await session.Pending.WaitAsync(session.Stop.Token).ConfigureAwait(false);
                foreach (var line in session.Queue.DequeueLines())
                {
                    // A single ordered writer; no task/semaphore backlog per event,
                    // no flush timer, no Nagle delay and no UI-thread network I/O.
                    var bytes = Encoding.UTF8.GetBytes(line + "\n");
                    await stream.WriteAsync(bytes, session.Stop.Token).ConfigureAwait(false);
                }
            }
        }
        catch (Exception ex) when (ex is IOException or SocketException or OperationCanceledException or ObjectDisposedException)
        {
            Disconnect(session, "Android connection closed.");
        }
    }

    private async Task ReadLoopAsync(Session session)
    {
        try
        {
            var data = new byte[128];
            while (await session.Client.GetStream().ReadAsync(data, session.Stop.Token).ConfigureAwait(false) != 0) { }
            Disconnect(session, "Android disconnected.");
        }
        catch (Exception ex) when (ex is IOException or SocketException or OperationCanceledException or ObjectDisposedException)
        {
            Disconnect(session, "Android connection closed.");
        }
    }

    private void Disconnect(Session session, string message)
    {
        bool changed;
        lock (_sync)
        {
            changed = ReferenceEquals(_session, session);
            if (changed) _session = null;
        }
        session.Close();
        if (changed)
        {
            Log?.Invoke(message);
            ClientChanged?.Invoke(false);
        }
    }

    private async Task AcceptLoopAsync(TcpListener listener, CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                var client = await listener.AcceptTcpClientAsync(token).ConfigureAwait(false);
                client.NoDelay = true;
                // Keep OS buffering bounded so backpressure reaches our coalescing
                // queue instead of retaining a long history of pointer packets.
                client.SendBufferSize = 8192;
                Session? old;
                lock (_sync) old = _session;
                if (old is not null) Disconnect(old, "Android connection replaced.");
                var session = new Session(client);
                lock (_sync) _session = session;
                Log?.Invoke("Android connected from " + client.Client.RemoteEndPoint);
                ClientChanged?.Invoke(true);
                session.Writer = WriteLoopAsync(session);
                session.Reader = ReadLoopAsync(session);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) when (ex is SocketException or ObjectDisposedException)
            {
                if (token.IsCancellationRequested) break;
                Log?.Invoke("Accept error: " + ex.Message);
                try { await Task.Delay(250, token).ConfigureAwait(false); }
                catch (OperationCanceledException) { break; }
            }
        }
    }

    public async Task StopAsync()
    {
        var stop = _stop;
        _stop = null;
        stop?.Cancel();
        _listener?.Stop();
        _listener = null;
        // Wait for Accept to finish before detaching the last session so an
        // in-flight connection cannot appear after Stop.
        await _acceptTask.ConfigureAwait(false);
        Session? session;
        lock (_sync) { session = _session; _session = null; }
        if (session is not null)
        {
            session.Close();
            await Task.WhenAll(session.Writer, session.Reader).ConfigureAwait(false);
        }
        stop?.Dispose();
        ClientChanged?.Invoke(false);
    }
}
