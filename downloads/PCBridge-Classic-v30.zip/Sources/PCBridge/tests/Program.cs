using System.Net.Sockets;
using System.Text;
using System.Runtime.InteropServices;
using PCBridge;

static void Check(bool value, string message) { if (!value) throw new Exception(message); }
static void Equal<T>(T expected, T actual, string message) { Check(Equals(expected, actual), message + $": expected {expected}, got {actual}"); }
var passed = 0;
void Test(string name, Action body) { body(); Console.WriteLine("PASS " + name); passed++; }

Test("Raw Input ABI layout matches Win32 mouse and x64 header", () => {
    Equal(12, Marshal.OffsetOf<RAWMOUSE>(nameof(RAWMOUSE.lLastX)).ToInt32(), "RAWMOUSE X offset");
    Equal(16, Marshal.OffsetOf<RAWMOUSE>(nameof(RAWMOUSE.lLastY)).ToInt32(), "RAWMOUSE Y offset");
    Equal(24, Marshal.SizeOf<RAWMOUSE>(), "RAWMOUSE size");
    Equal(8, Marshal.OffsetOf<RAWINPUTHEADER>(nameof(RAWINPUTHEADER.hDevice)).ToInt32(), "RAWINPUTHEADER device offset");
    Equal(16, Marshal.OffsetOf<RAWINPUTHEADER>(nameof(RAWINPUTHEADER.wParam)).ToInt32(), "RAWINPUTHEADER wParam offset");
    Equal(24, Marshal.SizeOf<RAWINPUTHEADER>(), "RAWINPUTHEADER x64 size");
});
Test("Immediate split preserves large mouse deltas and full wheel", () => {
    var q = new InputReportQueue();
    Check(q.TryEnqueue("M,0,1000,-700,8", out var added) && added, "initial queued");
    var lines = q.DequeueLines().ToArray();
    var dx = 0; var dy = 0; var wheel = 0;
    foreach (var line in lines) {
        var p = line.Split(',').Skip(1).Select(int.Parse).ToArray();
        Check(p.Skip(1).All(n => n is >= -127 and <= 127), "HID range");
        dx += p[1]; dy += p[2]; wheel += p[3];
    }
    Equal(1000, dx, "total X"); Equal(-700, dy, "total Y"); Equal(8, wheel, "total scroll");
});
Test("Adjacent mouse motion merges without additional wakeups", () => {
    var q = new InputReportQueue();
    q.TryEnqueue("M,0,1,2,0", out var added); Check(added, "first wakeup");
    q.TryEnqueue("M,0,3,4,2", out added); Check(!added, "merged wakeup");
    Equal("M,0,4,6,2", q.DequeueLines().Single(), "merged movement");
});
Test("Button transitions and keyboard are FIFO barriers", () => {
    var q = new InputReportQueue();
    string[] input = ["M,0,5,0,0", "M,1,0,0,0", "M,1,8,9,0", "K,2,4,0,0,0,0,0", "M,1,2,3,0", "M,0,0,0,0", "K,0,0,0,0,0,0,0"];
    foreach (var line in input) Check(q.TryEnqueue(line, out _), "enqueue " + line);
    string[] expected = ["M,0,5,0,0", "M,1,8,9,0", "K,2,4,0,0,0,0,0", "M,1,2,3,0", "M,0,0,0,0", "K,0,0,0,0,0,0,0"];
    foreach (var line in expected) Equal(line, q.DequeueLines().Single(), "transition ordering");
});
Test("Bounded transition queue rejects overload without deleting input", () => {
    var q = new InputReportQueue(2);
    Check(q.TryEnqueue("K,1,4,0,0,0,0,0", out _), "first");
    Check(q.TryEnqueue("K,0,0,0,0,0,0,0", out _), "release");
    Check(!q.TryEnqueue("M,1,0,0,0", out _), "overload signalled");
    Equal("K,1,4,0,0,0,0,0", q.DequeueLines().Single(), "first preserved");
    Equal("K,0,0,0,0,0,0,0", q.DequeueLines().Single(), "release preserved");
});
Test("Fractional speed retains tiny movement and high-resolution wheel", () => {
    var m = new MouseMotionScaler();
    var x = 0;
    for (var i=0;i<4;i++) x += m.Scale(1, 0, 0.25).Dx;
    Equal(1,x,"quarter-speed accumulated");
    Equal(0,m.ScaleWheel(40),"wheel fraction one");
    Equal(0,m.ScaleWheel(40),"wheel fraction two");
    Equal(1,m.ScaleWheel(40),"wheel full notch");
    m.Scale(1,0,0.25); m.ScaleWheel(40); m.Reset();
    Equal(0,m.Scale(1,0,0.25).Dx,"movement reset"); Equal(0,m.ScaleWheel(80),"wheel reset");
});

var bridge = new NetworkBridge(0);
try {
    await bridge.StartAsync();
    var connected = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var disconnected = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    bridge.ClientChanged += value => { if(value) connected.TrySetResult(); else disconnected.TrySetResult(); };
    using var client = new TcpClient { NoDelay = true };
    await client.ConnectAsync("127.0.0.1", bridge.LocalPort);
    await connected.Task.WaitAsync(TimeSpan.FromSeconds(5));
    using var reader = new StreamReader(client.GetStream(), Encoding.UTF8);
    bridge.Send("M,0,300,-200,5");
    bridge.Send("K,2,4,0,0,0,0,0");
    bridge.Send("K,0,0,0,0,0,0,0");
    var x = 0;var y=0;var wheel=0;
    for (var i=0;i<3;i++) {
        var line = await reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5));
        var p=line!.Split(','); Equal("M",p[0],"mouse report first");
        x+=int.Parse(p[2]);y+=int.Parse(p[3]);wheel+=int.Parse(p[4]);
    }
    Equal(300,x,"loopback X"); Equal(-200,y,"loopback Y"); Equal(5,wheel,"loopback scroll");
    Equal("K,2,4,0,0,0,0,0",await reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5)),"press follows movement");
    Equal("K,0,0,0,0,0,0,0",await reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5)),"release follows press");
    client.Dispose();
    await disconnected.Task.WaitAsync(TimeSpan.FromSeconds(5));
    Check(!bridge.IsConnected,"peer EOF updates connected state");
    Console.WriteLine("PASS Ordered TCP loopback, split movement, keyboard release and remote EOF");passed++;
} finally { await bridge.StopAsync(); }

Console.WriteLine($"{passed} tests passed");
