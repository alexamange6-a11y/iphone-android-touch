using System.Runtime.InteropServices;

namespace PCBridge;

[StructLayout(LayoutKind.Sequential)] internal struct RAWINPUTDEVICE
    {
        public ushort usUsagePage;
        public ushort usUsage;
        public uint dwFlags;
        public nint hwndTarget;
    }

[StructLayout(LayoutKind.Sequential)] internal struct RAWINPUTHEADER
    {
        public uint dwType;
        public uint dwSize;
        public nint hDevice;
        public nint wParam;
    }

    // RAWMOUSE has a 4-byte union immediately after usFlags.
    // Keep that union as one uint so lLastX/lLastY are read at the correct
    // native offsets (12 and 16 on x64). The previous layout placed
    // lLastX at offset 8, so X movement was read from ulRawButtons and
    // appeared as dx=0 while lLastY actually contained the real X value.
[StructLayout(LayoutKind.Sequential)] internal struct RAWMOUSE
    {
        public ushort usFlags;
        public ushort _padding;
        public uint buttonsUnion;
        public uint ulRawButtons;
        public int lLastX;
        public int lLastY;
        public uint ulExtraInformation;
    }

