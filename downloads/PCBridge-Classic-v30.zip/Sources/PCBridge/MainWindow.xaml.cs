using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Interop;

namespace PCBridge;

public partial class MainWindow : Window
{
    private readonly NetworkBridge _network = new(45678);
    private readonly InputBridge _input;
    private bool _serverRunning;
    private bool _controlMode;

    public MainWindow()
    {
        InitializeComponent();
        IpText.Text = string.Join(", ", NetworkHelpers.GetLocalIPv4Addresses());
        StatusText.Text = "Server: OFF · Android: not connected · Control: OFF";

        _network.ClientChanged += connected => Dispatcher.BeginInvoke(() =>
        {
            ControlButton.IsEnabled = connected;
            StatusText.Text = $"Server: {(_serverRunning ? "ON" : "OFF")} · Android: {(connected ? "connected" : "not connected")} · Control: {(_controlMode ? "ON" : "OFF")}";
            if (!connected && _controlMode)
            {
                SetControlMode(false);
            }
        });
        _network.Log += Log;

        _input = new InputBridge();
        SourceInitialized += (_, _) => _input.AttachRawInput(this);
        _input.Message += message => _network.Send(message);
        _input.Diagnostic += message => Dispatcher.BeginInvoke(() => Log(message));
        _input.ReleaseRequested += () => Dispatcher.BeginInvoke(() => SetControlMode(false));
    }

    private async void ServerButton_Click(object sender, RoutedEventArgs e)
    {
        ServerButton.IsEnabled = false;
        try
        {
            if (!_serverRunning)
            {
                try
                {
                    await _network.StartAsync();
                    _serverRunning = true;
                    ServerButton.Content = "Остановить сервер";
                    Log("TCP server started on port 45678.");
                }
                catch (Exception ex)
                {
                    Log("Server error: " + ex.Message);
                }
            }
            else
            {
                SetControlMode(false);
                await _network.StopAsync();
                _serverRunning = false;
                ServerButton.Content = "Запустить сервер";
                ControlButton.IsEnabled = false;
                Log("TCP server stopped.");
            }
        }
        finally
        {
            ServerButton.IsEnabled = true;
            StatusText.Text = $"Server: {(_serverRunning ? "ON" : "OFF")} · Android: {(_network.IsConnected ? "connected" : "not connected")} · Control: {(_controlMode ? "ON" : "OFF")}";
        }
    }

    private void ControlButton_Click(object sender, RoutedEventArgs e)
        => SetControlMode(!_controlMode);

    private void SpeedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (SpeedValueText is not null)
            SpeedValueText.Text = $"{e.NewValue:0.00}×";
        if (_input is not null)
            _input.CursorSpeed = e.NewValue;
    }

    private void SetControlMode(bool enabled)
    {
        enabled = enabled && _network.IsConnected;
        _controlMode = _input.SetCapture(enabled);
        ControlButton.Content = _controlMode ? "Control mode ON" : "Control mode OFF";
        ControlButton.IsEnabled = _network.IsConnected;
        StatusText.Text = $"Server: {(_serverRunning ? "ON" : "OFF")} · Android: {(_network.IsConnected ? "connected" : "not connected")} · Control: {(_controlMode ? "ON" : "OFF")}";
        Log(_controlMode
            ? "CONTROL MODE ON — keyboard/mouse are redirected to Android. F12 releases it."
            : "CONTROL MODE OFF — local keyboard/mouse restored.");
    }

    private void Log(string text)
    {
        Dispatcher.BeginInvoke(() =>
        {
            LogBox.AppendText($"{DateTime.Now:HH:mm:ss}  {text}{Environment.NewLine}");
            if (LogBox.LineCount > 500) LogBox.Text = string.Join(Environment.NewLine, LogBox.Text.Split(Environment.NewLine).TakeLast(250));
            LogBox.ScrollToEnd();
        });
    }

    protected override async void OnClosed(EventArgs e)
    {
        SetControlMode(false);
        await _network.StopAsync();
        _input.Dispose();
        base.OnClosed(e);
    }
}

internal static class NetworkHelpers
{
    public static IReadOnlyList<string> GetLocalIPv4Addresses()
    {
        var result = new List<string>();
        foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                continue;
            foreach (var ua in ni.GetIPProperties().UnicastAddresses)
            {
                if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address))
                    result.Add(ua.Address.ToString());
            }
        }
        return result.Distinct().ToArray();
    }
}

internal sealed class InputBridge : IDisposable
{
    private const int WH_KEYBOARD_LL = 13;
    private const int WH_MOUSE_LL = 14;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;
    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_RBUTTONUP = 0x0205;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MBUTTONUP = 0x0208;
    private const int WM_MOUSEWHEEL = 0x020A;
    private const int VK_F12 = 0x7B;
    private const int WM_INPUT = 0x00FF;
    private const uint RID_INPUT = 0x10000003;
    private const uint RIM_TYPEMOUSE = 0;
    private const uint RIDEV_INPUTSINK = 0x00000100;

    private readonly LowLevelKeyboardProc _keyboardProc;
    private readonly LowLevelMouseProc _mouseProc;
    private nint _keyboardHook;
    private nint _mouseHook;
    private volatile bool _capture;
    private byte _modifier;
    private readonly HashSet<byte> _keys = new();
    private byte _mouseButtons;
    private readonly MouseMotionScaler _motion = new();
    private bool _rawInputReady;
    private HwndSource? _rawSource;
    private nint _rawBuffer;
    private uint _rawBufferSize;
    private double _cursorSpeed = 1.0;

    public double CursorSpeed
    {
        get => Volatile.Read(ref _cursorSpeed);
        set => Volatile.Write(ref _cursorSpeed, Math.Clamp(value, 0.25, 3.0));
    }

    public event Action<string>? Message;
    public event Action<string>? Diagnostic;
    public event Action? ReleaseRequested;

    public InputBridge()
    {
        _keyboardProc = KeyboardHook;
        _mouseProc = MouseHook;
    }

    public bool SetCapture(bool enabled)
    {
        if (_capture == enabled) return _capture;
        if (enabled)
        {
            if (!_rawInputReady) { Diagnostic?.Invoke("Raw Input unavailable; control mode not enabled."); return false; }
            InstallHooks();
            if (_keyboardHook == 0 || _mouseHook == 0)
            {
                UninstallHooks();
                Diagnostic?.Invoke("Input capture failed; control mode not enabled.");
                return false;
            }
            _motion.Reset();
            _capture = true;
            SendKeyboardReport();
            SendMouseReport(0, 0, 0);
        }
        else
        {
            _capture = false;
            UninstallHooks();
            _motion.Reset();
            _keys.Clear();
            _modifier = 0;
            _mouseButtons = 0;
            SendKeyboardReport();
            SendMouseReport(0, 0, 0);
        }
        return _capture;
    }

    private void InstallHooks()
    {
        if (_keyboardHook == 0)
        {
            _keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, _keyboardProc, nint.Zero, 0);
            if (_keyboardHook == 0) Diagnostic?.Invoke("ERROR: keyboard hook failed, Win32=" + Marshal.GetLastWin32Error());
        }
        if (_mouseHook == 0)
        {
            _mouseHook = SetWindowsHookEx(WH_MOUSE_LL, _mouseProc, nint.Zero, 0);
            if (_mouseHook == 0) Diagnostic?.Invoke("ERROR: mouse hook failed, Win32=" + Marshal.GetLastWin32Error());
        }
    }

    private void UninstallHooks()
    {
        if (_keyboardHook != 0) { UnhookWindowsHookEx(_keyboardHook); _keyboardHook = 0; }
        if (_mouseHook != 0) { UnhookWindowsHookEx(_mouseHook); _mouseHook = 0; }
    }

    private nint KeyboardHook(int nCode, nint wParam, nint lParam)
    {
        if (nCode < 0) return CallNextHookEx(0, nCode, wParam, lParam);
        var data = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
        int vk = unchecked((int)data.vkCode);
        bool down = wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN;
        bool up = wParam == WM_KEYUP || wParam == WM_SYSKEYUP;

        if (!_capture) return CallNextHookEx(0, nCode, wParam, lParam);

        // Release inputs immediately on the hook thread; UI cleanup can wait.
        if (down && vk == VK_F12)
        {
            SetCapture(false);
            Diagnostic?.Invoke("F12 — control released.");
            ReleaseRequested?.Invoke();
            return 1;
        }

        if (TryGetModifierUsage(data.vkCode, data.scanCode, data.flags, out var modBit, out var rightModUsage))
        {
            if (down) _modifier |= modBit;
            if (up) _modifier &= (byte)~modBit;
            SendKeyboardReport();
            return 1;
        }

        if (!TryMapVkToHid((int)data.vkCode, out var usage))
            return 1;

        if (down) _keys.Add(usage);
        if (up) _keys.Remove(usage);
        SendKeyboardReport();
        return 1;
    }

    private nint MouseHook(int nCode, nint wParam, nint lParam)
    {
        if (nCode < 0) return CallNextHookEx(0, nCode, wParam, lParam);
        if (!_capture) return CallNextHookEx(0, nCode, wParam, lParam);

        var data = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);

        switch ((int)wParam)
        {
            case WM_MOUSEMOVE:
                // Movement comes from Raw Input in HandleRawInput().
                // The low-level hook is only used to suppress the normal Windows cursor movement.
                break;

            case WM_LBUTTONDOWN: _mouseButtons |= 1; SendMouseReport(0, 0, 0); break;
            case WM_LBUTTONUP: _mouseButtons &= 0xFE; SendMouseReport(0, 0, 0); break;
            case WM_RBUTTONDOWN: _mouseButtons |= 2; SendMouseReport(0, 0, 0); break;
            case WM_RBUTTONUP: _mouseButtons &= 0xFD; SendMouseReport(0, 0, 0); break;
            case WM_MBUTTONDOWN: _mouseButtons |= 4; SendMouseReport(0, 0, 0); break;
            case WM_MBUTTONUP: _mouseButtons &= 0xFB; SendMouseReport(0, 0, 0); break;
            case WM_MOUSEWHEEL:
                short wheel = unchecked((short)((data.mouseData >> 16) & 0xFFFF));
                int steps = _motion.ScaleWheel(wheel);
                if (steps != 0) SendMouseReport(0, 0, steps);
                break;
        }

        return 1;
    }

    public void AttachRawInput(Window window)
    {
        var source = PresentationSource.FromVisual(window) as HwndSource;
        if (source is null) return;
        source.AddHook(RawInputWndProc);
        _rawSource = source;

        var device = new RAWINPUTDEVICE
        {
            usUsagePage = 0x01,
            usUsage = 0x02,
            dwFlags = RIDEV_INPUTSINK,
            hwndTarget = source.Handle
        };
        if (!RegisterRawInputDevices(new[] { device }, 1, (uint)Marshal.SizeOf<RAWINPUTDEVICE>()))
            Diagnostic?.Invoke("ERROR: Raw Input registration failed, Win32=" + Marshal.GetLastWin32Error());
        else
        {
            _rawInputReady = true;
            Diagnostic?.Invoke("Raw Input mouse: OK");
        }
    }

    private nint RawInputWndProc(nint hwnd, int msg, nint wParam, nint lParam, ref bool handled)
    {
        if (msg == WM_INPUT && _capture)
        {
            HandleRawInput(lParam);
            // Let DefWindowProc perform WM_INPUT foreground cleanup.
            handled = false;
        }
        return nint.Zero;
    }

    private void HandleRawInput(nint lParam)
    {
        uint size = 0;
        uint headerSize = (uint)Marshal.SizeOf<RAWINPUTHEADER>();
        if (GetRawInputData(lParam, RID_INPUT, nint.Zero, ref size, headerSize) == uint.MaxValue || size == 0)
            return;

        if (_rawBufferSize < size)
        {
            if (_rawBuffer != nint.Zero) Marshal.FreeHGlobal(_rawBuffer);
            _rawBuffer = Marshal.AllocHGlobal((int)size);
            _rawBufferSize = size;
        }
        if (GetRawInputData(lParam, RID_INPUT, _rawBuffer, ref size, headerSize) == uint.MaxValue) return;
        var header = Marshal.PtrToStructure<RAWINPUTHEADER>(_rawBuffer);
        if (header.dwType != RIM_TYPEMOUSE) return;
        var mouse = Marshal.PtrToStructure<RAWMOUSE>(nint.Add(_rawBuffer, (int)headerSize));
        // Absolute tablet/touch input is not relative mouse motion.
        if ((mouse.usFlags & 1) != 0 || (mouse.lLastX == 0 && mouse.lLastY == 0)) return;
        var (dx, dy) = _motion.Scale(mouse.lLastX, mouse.lLastY, CursorSpeed);
        if (dx != 0 || dy != 0) SendMouseReport(dx, dy, 0);
    }

    private void SendMouseReport(int dx, int dy, int wheel)
        => Message?.Invoke(FormattableString.Invariant($"M,{_mouseButtons},{dx},{dy},{wheel}"));

    internal static string BuildKeyLine(byte modifier, IEnumerable<byte> keys)
    {
        var k = keys.OrderBy(x => x).Take(6).ToArray();
        var six = new byte[6];
        Array.Copy(k, six, k.Length);
        return $"K,{modifier},{six[0]},{six[1]},{six[2]},{six[3]},{six[4]},{six[5]}";
    }

    private void SendKeyboardReport() => Message?.Invoke(BuildKeyLine(_modifier, _keys));

    internal static bool TryGetModifierUsage(uint vk, uint scanCode, uint flags, out byte bit, out byte usage)
    {
        bit = 0; usage = 0;
        switch (vk)
        {
            // Low-level hook отдаёт Shift/Ctrl/Alt как левые/правые коды (0xA0..0xA5)
            case 0xA0: bit = 0x02; usage = 0xE1; return true; // LShift
            case 0xA1: bit = 0x20; usage = 0xE5; return true; // RShift
            case 0xA2: bit = 0x01; usage = 0xE0; return true; // LCtrl
            case 0xA3: bit = 0x10; usage = 0xE4; return true; // RCtrl
            case 0xA4: bit = 0x04; usage = 0xE2; return true; // LAlt
            case 0xA5: bit = 0x40; usage = 0xE6; return true; // RAlt / AltGr
            case 0x10: bit = (scanCode == 0x36) ? (byte)0x20 : (byte)0x02; usage = (scanCode == 0x36) ? (byte)0xE5 : (byte)0xE1; return true;
            case 0x11: bit = ((flags & 0x01) != 0) ? (byte)0x10 : (byte)0x01; usage = ((flags & 0x01) != 0) ? (byte)0xE4 : (byte)0xE0; return true;
            case 0x12: bit = ((flags & 0x01) != 0) ? (byte)0x40 : (byte)0x04; usage = ((flags & 0x01) != 0) ? (byte)0xE6 : (byte)0xE2; return true;
            case 0x5B: bit = 0x08; usage = 0xE3; return true;
            case 0x5C: bit = 0x80; usage = 0xE7; return true;
            default: return false;
        }
    }

    internal static bool TryMapVkToHid(int vk, out byte usage)
    {
        if (vk is >= 0x41 and <= 0x5A) { usage = (byte)(0x04 + vk - 0x41); return true; }
        if (vk is >= 0x31 and <= 0x39) { usage = (byte)(0x1E + vk - 0x31); return true; }
        if (vk == 0x30) { usage = 0x27; return true; }
        usage = vk switch
        {
            0x0D => 0x28, 0x1B => 0x29, 0x08 => 0x2A, 0x09 => 0x2B, 0x20 => 0x2C,
            0xBD => 0x2D, 0xBB => 0x2E, 0xDB => 0x2F, 0xDD => 0x30,
            0xDC => 0x31, 0xBA => 0x33, 0xDE => 0x34, 0xC0 => 0x35,
            0xBC => 0x36, 0xBE => 0x37, 0xBF => 0x38, 0x14 => 0x39,
            0x70 => 0x3A, 0x71 => 0x3B, 0x72 => 0x3C, 0x73 => 0x3D,
            0x74 => 0x3E, 0x75 => 0x3F, 0x76 => 0x40, 0x77 => 0x41,
            0x78 => 0x42, 0x79 => 0x43, 0x7A => 0x44, 0x7B => 0x45,
            0x2C => 0x46, 0x91 => 0x47, 0x13 => 0x48,
            0x2D => 0x49, 0x24 => 0x4A, 0x21 => 0x4B, 0x2E => 0x4C,
            0x23 => 0x4D, 0x22 => 0x4E, 0x27 => 0x4F, 0x25 => 0x50,
            0x28 => 0x51, 0x26 => 0x52,
            0x90 => 0x53, 0x6F => 0x54, 0x6A => 0x55, 0x6D => 0x56,
            0x6B => 0x57, 0x60 => 0x62, 0x61 => 0x59, 0x62 => 0x5A,
            0x63 => 0x5B, 0x64 => 0x5C, 0x65 => 0x5D, 0x66 => 0x5E,
            0x67 => 0x5F, 0x68 => 0x60, 0x69 => 0x61, 0x6E => 0x63,
            _ => (byte)0
        };
        return usage != 0;
    }

    public void Dispose()
    {
        SetCapture(false);
        _rawSource?.RemoveHook(RawInputWndProc);
        if (_rawInputReady)
        {
            var device = new RAWINPUTDEVICE { usUsagePage = 1, usUsage = 2, dwFlags = 1, hwndTarget = nint.Zero };
            RegisterRawInputDevices(new[] { device }, 1, (uint)Marshal.SizeOf<RAWINPUTDEVICE>());
            _rawInputReady = false;
        }
        if (_rawBuffer != nint.Zero) { Marshal.FreeHGlobal(_rawBuffer); _rawBuffer = nint.Zero; }
    }

    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int x, y; }
    [StructLayout(LayoutKind.Sequential)] private struct MSLLHOOKSTRUCT { public POINT pt; public uint mouseData, flags, time; public nint dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] private struct KBDLLHOOKSTRUCT { public uint vkCode, scanCode, flags, time; public nint dwExtraInfo; }

    private delegate nint LowLevelKeyboardProc(int nCode, nint wParam, nint lParam);
    private delegate nint LowLevelMouseProc(int nCode, nint wParam, nint lParam);

    [DllImport("user32.dll", SetLastError = true)] private static extern uint GetRawInputData(nint hRawInput, uint uiCommand, nint pData, ref uint pcbSize, uint cbSizeHeader);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool RegisterRawInputDevices(RAWINPUTDEVICE[] pRawInputDevices, uint uiNumDevices, uint cbSize);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern nint SetWindowsHookEx(int idHook, Delegate lpfn, nint hMod, uint dwThreadId);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool UnhookWindowsHookEx(nint hhk);
    [DllImport("user32.dll")] private static extern nint CallNextHookEx(nint hhk, int nCode, nint wParam, nint lParam);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern nint GetModuleHandle(string? lpModuleName);
}
